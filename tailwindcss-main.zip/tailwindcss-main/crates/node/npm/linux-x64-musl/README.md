# `@tailwindcss/oxide-linux-x64-musl`

This is the **x86_64-unknown-linux-musl** binary for `@tailwindcss/oxide`
